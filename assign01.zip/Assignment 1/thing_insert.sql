SELECT * FROM Assignment1.thing;

-- inserting values 
INSERT INTO `Assignment1`.`thing` (`manufacturer`, `model`, `submodel`, `pickup/acoutic/both`, `price`) VALUES ('Fender', 'Stratocaster', 'KENNY WAYNE SHEPHERD', 'Pick-up', 1999.99);

INSERT INTO `Assignment1`.`thing` (`manufacturer`, `model`, `submodel`, `pickup/acoutic/both`, `price`) VALUES ('Gibson' , 'Les Paul' , 'V1 Deep Cherry Sunburst' , 'Pick-up' , 6499.00);

INSERT INTO `Assignment1`.`thing` (`manufacturer`, `model`, `submodel`, `pickup/acoutic/both`, `price`) VALUES ('Fender', 'Telecaster', 'VINTERA ROAD WORN `70S', 'Pick-up', 1099.99);

INSERT INTO `Assignment1`.`thing` (`manufacturer`, `model`, `submodel`, `pickup/acoutic/both`, `price`) VALUES ('Fender', 'Concert' , 'FA-235E' , 'Acoustic' , 329.99);

INSERT INTO `Assignment1`.`thing` (`manufacturer`, `model`, `submodel`, `pickup/acoutic/both`, `price`) VALUES ('Gibson', 'SG' , 'Junior' , 'Pick-up' , 1399.00);

INSERT INTO `Assignment1`.`thing` (`manufacturer`, `model`, `submodel`, `pickup/acoutic/both`, `price`) VALUES ('Gibson', 'Dove' , 'Original' , 'Both' , 4299.00);
