CREATE TABLE `thing` (
  `manufacturer` tinytext,
  `model` tinytext,
  `submodel` varchar(23) NOT NULL,
  `pickup/acoutic/both` tinytext,
  `price` decimal(6,2) DEFAULT NULL,
  PRIMARY KEY (`submodel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci